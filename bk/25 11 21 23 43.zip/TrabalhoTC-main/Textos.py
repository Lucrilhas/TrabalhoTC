txts = {
    'Guias': ['Deterministico', 'Não Deterministico', 'Deterministico de Pilha', 'Não Deterministicos de Pilha'],

    'AFD': 'Um autômato finito determinístico, também chamado máquina de estados finita determinística (AFD), '
           'É uma Máquina\nde estados finita que aceita ou rejeita cadeias de símbolos gerando um único ramo de '
           'computação para cada cadeia de\nentrada. Estas sendo configuradas em um tipo chamado de 5-Tupla.',

    'Exp5Tupla':    'Uma 5-Tupla P = { Q, \u03A3, \u03B4, q\u2080, F }.\n'
                    'Sendo \' Q \' o conjunto de estados.\n'
                    'Sendo \' \u03A3 \' o alfabeto de entradas.\n'
                    'Sendo \' \u03B4 : Q \u2613 \u03A3\u2091 \u2613 P(Q) \' a função de  transição.\n'
                    'Sendo \' q\u2080 \u2208 Q \' o estado inicial.\n'
                    'Sendo \' F \u2286 Q \' é o conjunto de estados finais.',

    'Col5Tupla': [
                    'Conjunto de estados Q: ',
                    'Alfabeto de entradas \u03A3: ',
                    'Estado inicial q\u2080',
                    'Estados Finais F: ',
                    'Palavra para testar:'
    ]
}