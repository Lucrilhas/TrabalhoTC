## Trabalho de Teoria da Computação
Este código foi criado no intuito de servir como implementação 
para o trabalho final da materia de teoria da computação 2021.1 
ministrada pela professora Dr. Nubia Rosa da Silva Guimarães na
Universidade federal de Catalão - UFCAT.<br>

##### Nossos nomes e contatos:
* Filipe Andrade Peres.
    * filipeandrp@gmail.com
* Lucas Elias de Andrade Cruvinel.
    * lucascruvinel@discente.ufcat.edu.br
* Ramom Soares Mendes de Meneses Leite.
    * ramonsoares@discente.ufcat.edu.br
  
##### Tema
O tema escolhido para nossa implementação é o de autômato de pilha, 
e suas variações.