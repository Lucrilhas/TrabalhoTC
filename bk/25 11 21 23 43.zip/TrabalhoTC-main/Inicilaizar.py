import GUI

pg = GUI.Programa()
